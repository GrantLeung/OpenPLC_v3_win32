#!/bin/bash
cd webserver
python webserver.py
